首先安装EmmyLua-Unity-1.0.9.zip这个插件到Idea或者rider，如果安装的版本低了或者不安装都无法正常提示，低版本会造成不提示成员。

然后把EmmyLuaServiceExtension.cs这个文件复制到Unity项目的Editor文件夹中。

在菜单上会多出一个EmmyLua按钮，单机enable会开始进行API提示，Disable关闭。

